import re
from django.contrib.auth.models import Group,User
from django.shortcuts import render, redirect
from django.views import View
from .models import Customer,Product,Carts,EventRegistered
from .forms import CustomerRegistrationForm, CustomerProfileForm,OrgRegistrationForm

from django.contrib import messages
from django.db.models import Q
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

class ProductView(View):
  def get(self,request):
     # Topwears = Product.objects.filter(category='TW')
     # Jeans = Product.objects.filter(category='J')
     Hackathons = Product.objects.filter(category='H')
     Courses = Product.objects.filter(category='C')
     Internships = Product.objects.filter(category='I')
     Scholarships= Product.objects.filter(category='S')
     CulEvents= Product.objects.filter(category='CE')
     # Mask = Product.objects.filter(category='MK')
     # Grocerys = Product.objects.filter(category='G')
     # Kitchen_Essentials = Product.objects.filter(category='K')
     return render(request,'app/home.html',{'Hackathons':Hackathons, 'Courses':Courses, 'Internships':Internships, 'Scholarships':Scholarships, 'CulEvents':CulEvents})




#def product_detail(request):
 #return render(request, 'app/productdetail.html')
class ProductDetailView(View):
    def get(self, request, pk):
        product = Product.objects.get(pk=pk)
        item_already_in_cart= False
        if request.user.is_authenticated:
                    item_already_in_cart= Carts.objects.filter(Q(product=product.id) &Q(user=request.user))
        return render(request,'app/eventdetail.html',{'product':product ,'item_already_in_cart':item_already_in_cart})




@login_required()
def add_to_cart(request):
        user = request.user
        product_id = request.GET.get('prod_id')
        product = Product.objects.get(id=product_id)
        Carts(user=user, product=product).save()
        return redirect('/showevents')
@login_required()
def show_events(request):
    if request.user.is_authenticated:
        user = request.user
        cart = Carts.objects.filter(user=user)
        print(cart)
        amount = 0.0
        shipping_amount = 70.0
        total_amount = 0.0
        cart_product = [p for p in Carts.objects.all() if p.user == request.user]
        # print(cart_product)
        if cart_product:
            for p in cart_product:
                return render(request, 'app/showevents.html',{'cart':cart ,})
        else:
            return render(request, 'app/noevents.html')

# @login_required()
# def plus_cart(request):
#     if request.method == 'GET':
#         prod_id = request.GET['prod_id']
#         c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
#         c.quantity+=1
#         c.save()
#         amount=0.0
#         shipping_amount = 70
#         total_amount = 0.0
#         cart_product = [p for p in Cart.objects.all() if p.user==request.user]
#         for p in cart_product:
#             tempamount = (p.quantity * p.product.discounted_price)
#             amount += tempamount
#
#         data={
#             'quantity': c.quantity,
#             'amount': amount,
#             'totalamount':amount+shipping_amount
#         }
#         return JsonResponse(data)
#
# @login_required()
# def minus_cart(request):
#     if request.method == 'GET':
#         prod_id = request.GET['prod_id']
#         c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
#         c.quantity-=1
#         c.save()
#         amount=0.0
#         shipping_amount = 70
#         total_amount = 0.0
#         cart_product = [p for p in Cart.objects.all() if p.user==request.user]
#         for p in cart_product:
#             tempamount = (p.quantity * p.product.discounted_price)
#             amount += tempamount
#
#         data={
#             'quantity': c.quantity,
#             'amount': amount,
#             'totalamount':amount+shipping_amount
#         }
#         return JsonResponse(data)
#
# @login_required()
# def remove_cart(request):
#     if request.method == 'GET':
#         prod_id = request.GET['prod_id']
#         c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
#         c.quantity-=1
#         c.delete()
#         amount=0.0
#         shipping_amount = 70
#         total_amount = 0.0
#         cart_product = [p for p in Cart.objects.all() if p.user==request.user]
#         for p in cart_product:
#             tempamount = (p.quantity * p.product.discounted_price)
#             amount += tempamount
#
#         data={
#             'amount': amount,
#             'totalamount':amount+shipping_amount
#         }
#         return JsonResponse(data)
# @login_required()
# def buy_now(request):
#  return render(request, 'app/buynow.html')


@login_required()
def address(request):
 add = Customer.objects.filter(user=request.user)
 return render(request, 'app/address.html',{'add':add,'active':'btn-primary'})

@login_required()
def orders(request):
    op = EventRegistered.objects.filter(user=request.user)
    return render(request, 'app/orders.html',{'order_placed':op})

# @login_required()
# def pick(request):
#     op = PickOrderPlaced.objects.filter(user=request.user)
#     return render(request, 'app/pickup.html',{'pickorder_placed':op})

def Hackathons(request,data=None):
    if data == None:
        Hackathons = Product.objects.filter(category='H')

    return render(request, 'app/hackathons.html',{'Hackathons':Hackathons})

def Courses(request,data=None):
    if data == None:
        Courses = Product.objects.filter(category='C')

    return render(request, 'app/courses.html',{'Courses':Courses})

def Scholarships(request,data=None):
    if data == None:
        Scholarships = Product.objects.filter(category='S')

    return render(request, 'app/scholarships.html',{'Scholarships':Scholarships})

def Internships(request,data=None):
    if data == None:
        Internships = Product.objects.filter(category='I')

    return render(request, 'app/internships.html',{'Internships':Internships})

def CulEvents(request,data=None):
    if data == None:
        CulEvents = Product.objects.filter(category='CE')

    return render(request, 'app/culevents.html',{'CulEvents':CulEvents})
# def CovidMedicine(request):
#      CovidMedicines = Product.objects.filter(category='CM')
#     #elif data =='samsung' or data=='apple' or data=='oppo' or data=='redmi' :
#      #   mobiles = Product.objects.filter(category='M').filter(brand=data)
#      return render(request, 'app/CovidMedicine.html',{'CovidMedicines':CovidMedicines})
#
#
# def Mask(request):
#     Masks = Product.objects.filter(category='MK')
#     # elif data =='samsung' or data=='apple' or data=='oppo' or data=='redmi' :
#     #   mobiles = Product.objects.filter(category='M').filter(brand=data)
#     return render(request, 'app/Mask.html', {'Masks': Masks})
#
# def Sanitizer(request):
#     Sanitizers = Product.objects.filter(category='S')
#     # elif data =='samsung' or data=='apple' or data=='oppo' or data=='redmi' :
#     #   mobiles = Product.objects.filter(category='M').filter(brand=data)
#     return render(request, 'app/Sanitizer.html', {'Sanitizers': Sanitizers})
#
# def KitchenEssential(request, data=None):
#     if data == None:
#         KitchenEssentials = Product.objects.filter(category='K')
#     elif data == 'Sunflame' or data == 'Bajaj' or data == 'Usha' or data == 'Prestige':
#         KitchenEssentials = Product.objects.filter(category='K').filter(brand=data)
#     elif data == 'below':
#         KitchenEssentials = Product.objects.filter(category='K').filter(discounted_price__lt=1801)
#     elif data == 'above':
#         KitchenEssentials = Product.objects.filter(category='K').filter(discounted_price__gt=1800)
#
#     return render(request, 'app/KitchenEssential.html', {'KitchenEssentials': KitchenEssentials})
#
# def Grocery(request, data=None):
#     if data == None:
#         Grocerys = Product.objects.filter(category='G')
#     elif data == 'Fruits' or data == 'Vegetables' or data == 'Complan' or data == 'Amul' or data == 'Haldirams':
#         Grocerys = Product.objects.filter(category='G').filter(brand=data)
#     return render(request, 'app/Grocery.html', {'Grocerys': Grocerys})

def searchbar(request):
    if request.method == 'GET':
        search = request.GET.get('search')
        tle = Product.objects.all().filter(title__icontains=search)
        cat = Product.objects.all().filter(category__icontains=search)
        bnd = Product.objects.all().filter(brand__icontains=search)
        desc = Product.objects.all().filter(description__icontains=search)
        # pin = Product.objects.all().filter(pincode_of_shop=search)
        # add = Product.objects.all().filter(address__icontains=search)
        post=tle|cat|bnd|desc
        return render(request,'app/searchbar.html',{'post':post})

class OrgRegistrationView(View):

    def get(self,request):
        form =OrgRegistrationForm()
        return render(request, 'app/orgregistration.html',{'form':form})


    def post(self,request):
        form=OrgRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, 'Congratulations! You are registered Successfully!')
            user=form.save()
            group = Group.objects.get(name='ShopOwner')
            user.groups.add(group)
        return render(request,'app/orgregistration.html',{'form':form})


class CustomerRegistrationView(View):

    def get(self,request):
        form =CustomerRegistrationForm()
        return render(request, 'app/customerregistration.html',{'form':form})


    def post(self,request):
        form=CustomerRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, 'Congratulations! You are registered Successfully!')
            user = form.save()
            group = Group.objects.get(name='Customer')
            user.groups.add(group)
        return render(request,'app/customerregistration.html',{'form':form})


# @login_required()
# def checkout(request):
#     user = request.user
#     add = Customer.objects.filter(user=user)
#     cart_items = Cart.objects.filter(user=user)
#     amount = 0.0
#     shipping_amount = 70.0
#     totalamount = 0.0
#     cart_product = [p for p in Cart.objects.all() if p.user == request.user]
#     if cart_product:
#         for p in cart_product:
#             tempamount = (p.quantity * p.product.discounted_price)
#             amount += tempamount
#         totalamount = amount + shipping_amount
#     return render(request, 'app/checkout.html',{'add':add, 'totalamount':totalamount, 'cart_items':cart_items})

# @login_required()
# def checkout2(request):
#     user = request.user
#     add = Customer.objects.filter(user=user)
#     cart_items = Cart.objects.filter(user=user)
#     amount = 0.0
#     shipping_amount = 70.0
#     totalamount = 0.0
#     cart_product = [p for p in Cart.objects.all() if p.user == request.user]
#     if cart_product:
#         for p in cart_product:
#             tempamount = (p.quantity * p.product.discounted_price)
#             amount += tempamount
#         totalamount = amount + shipping_amount
#     return render(request, 'app/checkout2.html',{'add':add, 'totalamount':totalamount, 'cart_items':cart_items})
#
#
# @login_required()
# def payment_done(request):
#     user = request.user
#     custid = request.GET.get('custid')
#     customer = Customer.objects.get(id=custid)
#     cart = Cart.objects.filter(user=user)
#     for c in cart:
#         OrderPlaced(user=user, customer=customer, product=c.product, quantity=c.quantity).save()
#         c.delete()
#     return redirect("orders")
#
# @login_required()
# def pickpayment_done(request):
#     user = request.user
#     custid1 = request.GET.get('custid')
#     customer1 = Customer.objects.get(id=custid1)
#     cart1 = Cart.objects.filter(user=user)
#     for c in cart1:
#         PickOrderPlaced(user=user, customer=customer1, product=c.product, quantity=c.quantity).save()
#         c.delete()
#     return redirect("pick")

@method_decorator(login_required(), name='dispatch')
class ProfileView(View):
    def get(self, request):
        form = CustomerProfileForm()
        return render(request, 'app/profile.html' , {'form':form,'active':'btn-primary'})

    def post(self, request):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            usr = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            # Pincode = form.cleaned_data['Pincode']
            reg = Customer(user=usr,name=name, locality=locality, city=city)
            reg.save()
            messages.success(request, 'Congratulations!! Profile Updated Successfully')
            return render(request, 'app/profile.html', {'form':form,'active':'btn-primary'})








